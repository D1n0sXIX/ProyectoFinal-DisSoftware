package clases.nivel_2.enums;

public enum TipoPersonaje {
    GUERRERO,
    RANGO,
    APOYO
}
