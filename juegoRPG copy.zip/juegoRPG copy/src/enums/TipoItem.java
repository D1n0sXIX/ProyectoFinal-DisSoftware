package enums;

public enum TipoItem {
    ESPADA,
    ARCO,
    BACULO,
    ARMADURA,
    POCION,
    BOMBA
}
