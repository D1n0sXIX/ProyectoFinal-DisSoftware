package clases.nivel_2;

public interface Personaje {

    void atacar();
    void curar();
    void usarObjeto();

}
