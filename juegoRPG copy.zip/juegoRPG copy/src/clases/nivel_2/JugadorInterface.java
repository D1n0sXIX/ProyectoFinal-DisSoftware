package clases.nivel_2;

public interface JugadorInterface {

    void atacar(int cantidad);
    void curar(int cantidad);
    void usarObjeto();
    // Necesito que implementos estos metodos Doro
    String getNombre();
    void subirArmadura(int cantidad);
    int getDanio();
    void recibirDanio(int catidad);



}
