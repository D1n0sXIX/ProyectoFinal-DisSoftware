package clases.nivel_0;

public class Partida {

}
