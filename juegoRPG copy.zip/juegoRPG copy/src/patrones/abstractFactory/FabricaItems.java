package patrones.abstractFactory;
import clases.nivel_3.*;
<<<<<<< HEAD
import enums.TipoItems;
=======
import enums.TipoItem;
>>>>>>> itemArreglo

public class FabricaItems {
    public static Equipo crearItem(TipoItems tipo) {
        switch (tipo) {
            case POCION:
            case BOMBA:
<<<<<<< HEAD
                return new EquipoNoConsumible(tipo);
=======
                return new EquipoConsumible(tipo);
>>>>>>> itemArreglo
            case ESPADA:
            case ARCO:
            case BACULO:
            case ARMADURA:
                return new EquipoConsumible(tipo);
<<<<<<< HEAD
=======
            
            default: return null;
>>>>>>> itemArreglo
        }
    }
}

