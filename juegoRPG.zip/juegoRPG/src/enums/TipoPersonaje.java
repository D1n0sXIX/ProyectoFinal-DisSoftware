package enums;

public enum TipoPersonaje {
    LUCHADOR,
    RANGO,
    APOYO
}
